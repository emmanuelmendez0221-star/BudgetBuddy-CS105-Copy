BUDGETBUDDY — CS105 DELIVERABLE 4

PROJECT: BudgetBuddy.sln (Visual Basic, Windows Forms, .NET Framework 4.8).
ICON: Branding/BudgetBuddy.ico. The .vbproj sets ApplicationIcon so BudgetBuddy.exe has its own icon.
COMMENTED SOURCE: MainForm.vb and BudgetLogic.vb include explanations of events, processing, decisions and validation.

TO OPEN/BUILD ON WINDOWS:
1. Extract this ZIP. Open BudgetBuddy.sln using Visual Studio with .NET desktop development and .NET Framework 4.8 targeting pack installed.
2. Right-click BudgetBuddy project > Set as Startup Project, then press F5 to test.
3. Build > Build Solution (or Release configuration). The built file is BudgetBuddy/BudgetBuddy/bin/Debug/BudgetBuddy.exe or bin/Release/BudgetBuddy.exe.
4. To create a desktop shortcut: right-click the built BudgetBuddy.exe > Show more options > Send to > Desktop (create shortcut). Do NOT move the EXE away from its companion files.
5. The icon may take time to appear if Windows caches an older executable icon.

IMPORTANT: This ZIP contains Visual Studio SOURCE, not a Windows-compiled EXE. A Windows PC is necessary for final GUI testing and compilation.
Data is held only while running; closing the app loses entries. Persistent storage is not required by the CS105 guide.

Submit this ZIP and the separate PDF user manual/test cases. Fill in your name on the manual if needed.
