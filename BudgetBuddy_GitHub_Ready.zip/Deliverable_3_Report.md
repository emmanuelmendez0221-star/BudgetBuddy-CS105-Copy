# BudgetBuddy
Deliverable 3 | Testing, debugging & remaining work | CS 105

Student Allowance and Spending Management System. Group members: Emmanuel Mendez and Andre Ramirez. Visual Basic Windows Forms App (.NET Framework 4.8), for Visual Studio 2026.

## 1. Evidence of testing

The application and the separate console-check project compiled against Microsoft .NET Framework 4.8 reference assemblies using the .NET SDK on Linux. The exact BudgetLogic.vb file and test source were also linked into a temporary .NET 10 console project for execution: 70 checks passed and 0 failed. These are actual calculation and validation checks; they do not establish that the latest Windows interface has passed manual testing.

| Test / input | Expected and observed logic result |
| --- | --- |
| Allowance 100; other income 20; expense 30 | Available 120; expenses 30; balance 90; spending 25%. PASS |
| Allowance 100; extra 20; gift 10; other 5 | All four source totals retained; available money 135. PASS |
| Income 100; expenses 79.99, 80, 100, 100.01 | Within budget, approaching limit, approaching limit, over budget. PASS |
| Income 0; expense 5 | Negative balance and over-budget message; percentage unavailable; no division by zero. PASS |
| Current savings 25; target 100 | Amount saved 25; needed 75; progress 25%; remaining amount in status. PASS |
| Savings 120 / goal 100; zero goal | Needed amount clamps to 0; progress caps at 100%; zero goal is achieved. PASS |
| Expenses 30 and 5; remove first row | Expense total becomes 5 and remaining balance recalculates. Removing last row clears total. PASS |
| Letters, negative values, missing category, fractional cents | Invalid amounts/categories rejected without altering recorded totals. PASS |
| Reset; repeated income; maximum totals | All four income sources reset; entries accumulate correctly; total caps enforced. PASS |

## Build evidence

```text
Build succeeded.
    0 Warning(s)
    0 Error(s)
Logic checks: 70 passed; 0 failed.
```

Complete evidence is included in the project ZIP: Evidence/build-framework48.txt, tests-build-framework48.txt and logic-tests.txt. Windows screenshots supplied during development show an earlier running interface; the final revision still needs manual verification.

# Syntax-error correction
Controlled debugging exercise - actual compiler evidence

## 2. Attempt to identify and correct a syntax error

A separate temporary copy of the application was deliberately modified to demonstrate syntax debugging. One End If was removed from btnAddExpense_Click. The working submission source was not modified by this exercise. This is a controlled demonstration, rather than an accidental error claimed from normal development.

## Before: incomplete If block

```text
If cboExpenseCategory.SelectedIndex < 0 Then
    ShowError("Select an expense category first.")
    cboExpenseCategory.Focus()
    Return

' End If was deliberately omitted in the temporary copy.
```

## Actual compiler diagnostic

```text
MainForm.vb(67,9): error BC30081:
'If' must end with a matching 'End If'.
```

The compiler identified the opening If statement without its matching terminator. The correction was to restore End If immediately after Return, before the following expense-processing statements.

## After: corrected If block

```text
If cboExpenseCategory.SelectedIndex < 0 Then
    ShowError("Select an expense category first.")
    cboExpenseCategory.Focus()
    Return
End If
```

## Verification after correction

```text
Build succeeded.
    0 Warning(s)
    0 Error(s)
```

The temporary copy was rebuilt after the original source was restored. Actual logs and the before/after snippet are in Evidence/SyntaxExercise/syntax-error-before.txt, syntax-fixed-build.txt and before-and-after.txt. These are command-line compiler results, not fabricated Visual Studio screenshots.

# Designer-error correction
Observed on Windows; corrective implementation completed

## 3. Actual error screenshot

Visual Studio displayed: Method 'System.Windows.Forms.DataGridView.Columns' not found, with five instances. Ignore and Continue allowed the Designer to proceed without resolving the error. Compilation had succeeded, so this revealed a separate Designer-loading issue.

## Correction attempted

The likely trigger was five indexed Columns(0)/Columns(1) expressions in InitializeComponent. They were replaced with named DataGridViewTextBoxColumn fields and direct property assignments. The columns are now inserted with AddRange, using a local cell-style object and BeginInit/EndInit initialization.

```text
Me.colExpenseCategory.FillWeight = 66.0!
Me.colExpenseAmount.FillWeight = 34.0!
Me.lstExpenses.Columns.AddRange(
    New DataGridViewColumn() {Me.colExpenseCategory, Me.colExpenseAmount})
```

The corrected application rebuilds with 0 warnings and 0 errors. Static inspection confirms the indexed column expressions were removed. Reopening the corrected form successfully in the Windows Designer is still unverified. Evidence/designer-correction.txt records the change, and designer-error-observed.png preserves the supplied screenshot.

## Other development corrections

During Framework conversion, missing System and System.Collections.Generic imports caused BC30002 type-resolution errors; adding the project imports corrected them. The blur/layout revision added PerMonitorV2 configuration, Windows compatibility settings, an autosizing title and simpler panels. Their final appearance still needs checking on Windows.

# Remaining work
Brief problems, incomplete features & planned improvements

## 4. Current problems and incomplete features

| Item | Current status / planned improvement |
| --- | --- |
| Windows Designer and display scaling | Reopen the corrected form and verify grid columns, title, layout and sharpness at 100%, 125% and 150% scaling. Successful final reload is pending. |
| Final interface regression test | Verify Add Income, Add Expense, Remove, Calculate, validation messages, Reset Yes/No and Exit on Windows. Logic checks do not replace these clicks. |
| Saving and loading | Data exists only for the current session and is lost on exit. Add a file or database in a later version. |
| Editing existing records | Expense removal is implemented. Editing a recorded expense or income transaction is not implemented. |
| Budget history and dates | There is one current budget session. Add weekly/monthly selection, transaction dates and past-period history. |
| Reports and charts | Add category charts and printable/exportable budget summaries. Not required for the current calculation prototype. |

## 5. Manual checks to finish on Windows

Use a fresh extraction of the corrected project, open BudgetBuddy.sln, Rebuild Solution, then View Designer and F5. Record actual outcomes; do not mark a case passed until it has been run on the latest revision.

| Case | Expected result to verify |
| --- | --- |
| Normal calculation | Post income 100 + 20 + 10 + 5 and expense 30. Enter savings 25 / target 100; Calculate. Income 135, balance 105, saved 25, needed 75, spending 22.22%, savings progress 25%. |
| Warning, overspending and Remove | Add 78: expenses 108 and 80% warning. Add 28: expenses 136 and balance -1. Remove the 28 row: expenses 108 and warning returns. |
| Validation and reset | Try letters, negatives, missing category and blank savings. Confirm rejection. Reset No preserves data; Reset Yes clears all fields and totals. |
| Screenshots | Capture successful Designer load, normal results, a warning/negative balance, and Visual Studio Build Output/Error List. |

The prototype has verified build and core-logic results, documented syntax debugging, and an observed Designer-error correction attempt. The pending Windows checks and planned features above are explicitly recorded as remaining work.
