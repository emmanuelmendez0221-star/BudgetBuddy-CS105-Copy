Imports System.Globalization
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Drawing.Drawing2D

' BudgetBuddy desktop application (CS105 final version).
' MainForm handles button clicks, input feedback and the visible budget summary.
' BudgetLogic.vb holds the reusable calculations and validation rules.
Public Partial Class MainForm
    Private ReadOnly ledger As New BudgetLedger()

    Public Sub New()
        InitializeComponent()
        ' Display the branded icon on the window title bar and Windows taskbar.
        ' The .ico file is also embedded in the executable by the project settings.
        Me.Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath)
        ' Sections follow the Deliverable 2 mock-up: Income | Expenses | Savings.
        grpIncome.TabIndex = 0
        grpExpense.TabIndex = 1
        grpSavings.TabIndex = 2
        grpSummary.TabIndex = 3
        footerPanel.TabIndex = 4
        btnViewBudget.TabIndex = 0
        btnReset.TabIndex = 1
        btnExit.TabIndex = 2
    End Sub

    ' Convert text entered by the user to a valid non-negative currency amount.
    ' Return False and show readable feedback when the amount is invalid.
    Private Function ReadMoney(field As TextBox, title As String, blankAsZero As Boolean, ByRef amount As Decimal) As Boolean
        If MoneyInput.TryRead(field.Text, blankAsZero, amount) Then Return True
        ShowError(title & ": enter 0 to 1,000,000 with at most two decimal places (125.50).")
        field.Focus()
        field.SelectAll()
        Return False
    End Function

    Private Sub ShowError(message As String)
        lblFeedback.ForeColor = Color.Firebrick
        lblFeedback.Text = message
    End Sub

    Private Sub Confirm(message As String)
        lblFeedback.ForeColor = Color.FromArgb(18, 60, 80)
        lblFeedback.Text = message
    End Sub

    Private Shared Function Money(value As Decimal) As String
        Return "BZ$ " & value.ToString("N2", CultureInfo.InvariantCulture)
    End Function

    Private Sub btnAddIncome_Click(sender As Object, e As EventArgs) Handles btnAddIncome.Click
        Dim allowance, extraMoney, giftMoney, otherIncome As Decimal
        If Not ReadMoney(txtAllowance, "Allowance", True, allowance) Then Return
        If Not ReadMoney(txtExtraMoney, "Extra money received", True, extraMoney) Then Return
        If Not ReadMoney(txtGiftMoney, "Gift money", True, giftMoney) Then Return
        If Not ReadMoney(txtOtherIncome, "Other income", True, otherIncome) Then Return
        Try
            ' All four mock-up income sources contribute once to available money.
            ledger.AddIncome(allowance, extraMoney, giftMoney, otherIncome)
        Catch ex As ArgumentException
            ShowError(ex.Message)
            Return
        End Try
        ' Clear only after success; another click cannot duplicate the same entry.
        For Each field In New TextBox() {txtAllowance, txtExtraMoney, txtGiftMoney, txtOtherIncome}
            field.Clear()
        Next
        RefreshBudgetTotals()
        Confirm("Income recorded: " & Money(allowance + extraMoney + giftMoney + otherIncome) & ".")
        txtAllowance.Focus()
    End Sub

    ' Event-driven programming: this procedure runs when Add Expense is clicked.
    ' It validates both required inputs before updating the ledger and the table.
    Private Sub btnAddExpense_Click(sender As Object, e As EventArgs) Handles btnAddExpense.Click
        If cboExpenseCategory.SelectedIndex < 0 Then
            ShowError("Select an expense category first.")
            cboExpenseCategory.Focus()
            Return
        End If
        Dim amount As Decimal
        If Not ReadMoney(txtExpenseAmount, "Expense", False, amount) Then Return
        Dim category = CStr(cboExpenseCategory.SelectedItem)
        Try
            ledger.AddExpense(category, amount)
        Catch ex As ArgumentException
            ShowError(ex.Message)
            Return
        End Try
        lstExpenses.Rows.Add(category, Money(amount))
        lstExpenses.ClearSelection()
        txtExpenseAmount.Clear()
        cboExpenseCategory.SelectedIndex = -1
        RefreshBudgetTotals()
        Confirm("Expense recorded: " & category & " - " & Money(amount) & ".")
        cboExpenseCategory.Focus()
    End Sub

    Private Sub btnRemoveExpense_Click(sender As Object, e As EventArgs) Handles btnRemoveExpense.Click
        If lstExpenses.SelectedRows.Count = 0 Then
            ShowError("Select an expense row, then click Remove.")
            lstExpenses.Focus()
            Return
        End If
        Dim index = lstExpenses.SelectedRows(0).Index
        ' Removing the same index from both places preserves category/amount pairing.
        ledger.RemoveExpense(index)
        lstExpenses.Rows.RemoveAt(index)
        RefreshBudgetTotals()
        Confirm("Selected expense removed. Totals and budget status updated.")
    End Sub

    ' Recalculate the display after each successful transaction.
    ' Decision-making changes the status color for warnings or overspending.
    Private Sub RefreshBudgetTotals()
        Dim result = ledger.Calculate(0D, 0D)
        lblTotalAvailable.Text = Money(result.TotalAvailable)
        lblTotalExpenses.Text = Money(result.TotalExpenses)
        lblRemainingBalance.Text = Money(result.RemainingBalance)
        lblSpendingPercentage.Text = If(result.SpendingPercentage.HasValue,
            result.SpendingPercentage.GetValueOrDefault().ToString("0.##", CultureInfo.InvariantCulture) & "%", "N/A - no income")
        lblBudgetStatus.Text = result.BudgetStatus
        lblBudgetStatus.ForeColor = If(result.TotalExpenses > result.TotalAvailable, Color.Firebrick,
            If(result.SpendingPercentage.GetValueOrDefault() >= 80D, Color.DarkGoldenrod, Color.FromArgb(18, 60, 80)))
        lblRemainingBalance.ForeColor = If(result.RemainingBalance < 0D, Color.Firebrick, Color.FromArgb(18, 60, 80))
    End Sub

    ' Calculate the savings status and full budget when View Budget is clicked.
    ' Pending transactions must be recorded first to avoid misleading totals.
    Private Sub btnViewBudget_Click(sender As Object, e As EventArgs) Handles btnViewBudget.Click
        ' Do not silently ignore income/expenses that have not been recorded.
        For Each field In New TextBox() {txtAllowance, txtExtraMoney, txtGiftMoney, txtOtherIncome}
            If Not String.IsNullOrWhiteSpace(field.Text) Then
                ShowError("Click Add Income to record pending income, or clear its fields.")
                field.Focus()
                Return
            End If
        Next
        If Not String.IsNullOrWhiteSpace(txtExpenseAmount.Text) OrElse cboExpenseCategory.SelectedIndex >= 0 Then
            ShowError("Record the pending expense, or clear its amount and category.")
            Return
        End If
        Dim currentSavings, goal As Decimal
        If Not ReadMoney(txtCurrentSavings, "Current savings (required)", False, currentSavings) Then Return
        If Not ReadMoney(txtSavingsGoal, "Savings goal (required)", False, goal) Then Return
        Dim result = ledger.Calculate(currentSavings, goal)
        RefreshBudgetTotals()
        ' Amount Saved appears explicitly in the plan's lower summary.
        lblAmountSaved.Text = Money(result.AmountSaved)
        lblSavingsNeeded.Text = Money(result.SavingsNeeded)
        lblSavingsStatus.Text = result.SavingsStatus
        lblSavingsProgress.Text = "Savings progress: " & result.SavingsProgress.ToString("0.##", CultureInfo.InvariantCulture) & "%"
        prgSavings.Value = CInt(Decimal.Truncate(result.SavingsProgress))
        Confirm("Budget calculated. Savings are tracked separately from spending money.")
    End Sub

    Private Sub SavingsChanged(sender As Object, e As EventArgs) Handles txtCurrentSavings.TextChanged, txtSavingsGoal.TextChanged
        ' Editing savings invalidates the previous calculation immediately.
        lblAmountSaved.Text = "Not calculated"
        lblSavingsNeeded.Text = "Not calculated"
        lblSavingsStatus.Text = "Savings goal not checked"
        lblSavingsProgress.Text = "Savings progress: not checked"
        prgSavings.Value = 0
    End Sub

    ' Ask permission before erasing all in-memory entries.
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        If MessageBox.Show("Clear all entries and totals?", "Reset BudgetBuddy", MessageBoxButtons.YesNo,
                           MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) <> DialogResult.Yes Then Return
        ledger.Reset()
        For Each field In New TextBox() {txtAllowance, txtExtraMoney, txtGiftMoney, txtOtherIncome,
                                         txtExpenseAmount, txtCurrentSavings, txtSavingsGoal}
            field.Clear()
        Next
        cboExpenseCategory.SelectedIndex = -1
        lstExpenses.Rows.Clear()
        RefreshBudgetTotals()
        lblSpendingPercentage.Text = "0%"
        lblAmountSaved.Text = Money(0D)
        lblSavingsNeeded.Text = Money(0D)
        lblBudgetStatus.Text = "Not Calculated"
        lblSavingsStatus.Text = "Savings goal not checked"
        lblSavingsProgress.Text = "Savings progress: not checked"
        prgSavings.Value = 0
        Confirm("All income sources, expenses and savings cleared.")
        txtAllowance.Focus()
    End Sub

    ' The wallet is drawn as shapes, so it remains sharp at every display scale.
    ' No downloaded image file or external asset is required.
    Private Sub headerPanel_Paint(sender As Object, e As PaintEventArgs) Handles headerPanel.Paint
        Using background As New LinearGradientBrush(headerPanel.ClientRectangle, Color.FromArgb(214, 234, 255), Color.FromArgb(178, 210, 249), LinearGradientMode.Horizontal)
            e.Graphics.FillRectangle(background, headerPanel.ClientRectangle)
        End Using
        Dim state = e.Graphics.Save()
        Try
            Dim scale = CSng(headerPanel.DeviceDpi) / 96.0F
            e.Graphics.ScaleTransform(scale, scale)
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
            Using green As New SolidBrush(Color.FromArgb(45, 145, 88)), lightGreen As New SolidBrush(Color.FromArgb(121, 193, 133)), blue As New SolidBrush(Color.FromArgb(29, 87, 140)), fold As New SolidBrush(Color.FromArgb(23, 64, 106)), white As New SolidBrush(Color.White)
                e.Graphics.FillPolygon(green, New Point() {New Point(25, 31), New Point(61, 9), New Point(74, 34), New Point(37, 52)})
                e.Graphics.FillPolygon(lightGreen, New Point() {New Point(34, 30), New Point(69, 18), New Point(78, 42), New Point(43, 53)})
                e.Graphics.FillEllipse(white, 51, 27, 10, 8)
                e.Graphics.FillRectangle(blue, 24, 35, 56, 39)
                e.Graphics.FillRectangle(fold, 62, 48, 22, 15)
                e.Graphics.FillEllipse(white, 68, 52, 7, 7)
            End Using
        Finally
            e.Graphics.Restore(state)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
