Imports System.Globalization

' Pure calculation and validation code can be tested without opening the form.
' INPUT VALIDATION: reject negative values, text and amounts above the limit.' Blank income fields may be treated as zero; required fields may not.
Public Module MoneyInput
    Public Const MaximumEntry As Decimal = 1000000D
    Public Const MaximumTotal As Decimal = 100000000D

    Public Function TryRead(text As String, blankAsZero As Boolean, ByRef amount As Decimal) As Boolean
        amount = 0D
        If String.IsNullOrWhiteSpace(text) Then Return blankAsZero
        ' Accept plain numbers with a dot as the decimal separator; no currency/group symbols.
        Dim style = NumberStyles.AllowDecimalPoint Or NumberStyles.AllowLeadingSign
        If Not Decimal.TryParse(text.Trim(), style, CultureInfo.InvariantCulture, amount) Then Return False
        Return amount >= 0D AndAlso amount <= MaximumEntry AndAlso Decimal.Round(amount, 2) = amount
    End Function
End Module

Public Class ExpenseEntry
    Public Property Category As String
    Public Property Amount As Decimal
End Class

Public Class BudgetResult
    Public Property TotalAvailable As Decimal
    Public Property TotalExpenses As Decimal
    Public Property RemainingBalance As Decimal
    Public Property AmountSaved As Decimal
    Public Property SavingsProgress As Decimal
    Public Property SavingsNeeded As Decimal
    Public Property SpendingPercentage As Nullable(Of Decimal)
    Public Property BudgetStatus As String
    Public Property SavingsStatus As String
End Class

' MODEL: totals and expenses are kept in memory while the program is open.' This is intentional: the course does not require a database or file storage.
Public Class BudgetLedger
    Public Shared ReadOnly Categories As String() = {
        "Food & Snacks", "Transportation", "School Supplies", "Entertainment",
        "Games/Applications", "Other Expenses"}
    Public Property TotalAllowance As Decimal
        Get
            Return allowanceTotal
        End Get
        Private Set(value As Decimal)
            allowanceTotal = value
        End Set
    End Property
    Public Property TotalOtherIncome As Decimal
        Get
            Return otherTotal
        End Get
        Private Set(value As Decimal)
            otherTotal = value
        End Set
    End Property
    Public Property TotalExtraMoney As Decimal
        Get
            Return extraTotal
        End Get
        Private Set(value As Decimal)
            extraTotal = value
        End Set
    End Property
    Public Property TotalGiftMoney As Decimal
        Get
            Return giftTotal
        End Get
        Private Set(value As Decimal)
            giftTotal = value
        End Set
    End Property
    Private extraTotal As Decimal
    Private giftTotal As Decimal
    Private allowanceTotal As Decimal
    Private otherTotal As Decimal
    Private ReadOnly entries As New List(Of ExpenseEntry)()
    Public ReadOnly Property TotalIncome As Decimal
        Get
            Return TotalAllowance + TotalExtraMoney + TotalGiftMoney + TotalOtherIncome
        End Get
    End Property
    Public ReadOnly Property TotalExpenses As Decimal
        Get
            Dim total As Decimal = 0D
            For Each entry In entries
                total += entry.Amount
            Next
            Return total
        End Get
    End Property
    Public ReadOnly Property ExpenseCount As Integer
        Get
            Return entries.Count
        End Get
    End Property

    ' Compatibility overload; the main form records all four mock-up income sources.
    Public Sub AddIncome(allowance As Decimal, otherIncome As Decimal)
        AddIncome(allowance, 0D, 0D, otherIncome)
    End Sub

    Public Sub AddIncome(allowance As Decimal, extraMoney As Decimal, giftMoney As Decimal, otherIncome As Decimal)
        ' Validate the whole transaction before changing any totals.
        For Each value In New Decimal() {allowance, extraMoney, giftMoney, otherIncome}
            ValidateAmount(value)
        Next
        Dim incoming = allowance + extraMoney + giftMoney + otherIncome
        If incoming <= 0D Then Throw New ArgumentException("Enter income greater than zero.")
        If TotalIncome + incoming > MoneyInput.MaximumTotal Then Throw New ArgumentException("Income total cannot exceed 100,000,000.")
        TotalAllowance += allowance
        TotalExtraMoney += extraMoney
        TotalGiftMoney += giftMoney
        TotalOtherIncome += otherIncome
    End Sub

    ' A selected row corresponds to the same index in the model and the expense list.
    Public Sub RemoveExpense(index As Integer)
        If index < 0 OrElse index >= entries.Count Then Throw New ArgumentException("Select an expense to remove.")
        entries.RemoveAt(index)
    End Sub

    Public Sub AddExpense(category As String, amount As Decimal)
        ValidateAmount(amount)
        If Array.IndexOf(Categories, category) < 0 Then Throw New ArgumentException("Select an expense category.")
        If amount <= 0D Then Throw New ArgumentException("Expense must be greater than zero.")
        If TotalExpenses + amount > MoneyInput.MaximumTotal Then Throw New ArgumentException("Expense total cannot exceed 100,000,000.")
        entries.Add(New ExpenseEntry With {.Category = category, .Amount = amount})
    End Sub

    ' PROCESSING: subtract expenses from income; calculate savings progress.
    ' IF / ELSEIF decisions determine the displayed budget warning.
    Public Function Calculate(currentSavings As Decimal, savingsGoal As Decimal) As BudgetResult
        ValidateAmount(currentSavings)
        ValidateAmount(savingsGoal)
        Dim result As New BudgetResult With {
            .TotalAvailable = TotalIncome,
            .TotalExpenses = TotalExpenses,
            .RemainingBalance = TotalIncome - TotalExpenses,
            .AmountSaved = currentSavings,
            .SavingsNeeded = Math.Max(0D, savingsGoal - currentSavings)}
        ' Guard against division by zero. A missing percentage displays as N/A in the UI.
        ' A zero target is already achieved; otherwise cap the progress bar at 100%.
        If savingsGoal = 0D Then
            result.SavingsProgress = 100D
        Else
            result.SavingsProgress = Math.Min(100D, currentSavings / savingsGoal * 100D)
        End If
        If TotalIncome > 0D Then result.SpendingPercentage = TotalExpenses / TotalIncome * 100D
        ' Check overspending first; the warning begins at exactly 80 percent.
        If TotalExpenses > TotalIncome Then
            result.BudgetStatus = "You have exceeded your available budget."
        ElseIf TotalIncome = 0D Then
            result.BudgetStatus = "Enter income to calculate your budget."
        ElseIf result.SpendingPercentage.GetValueOrDefault() >= 80D Then
            result.BudgetStatus = "Warning: You are approaching your spending limit."
        Else
            result.BudgetStatus = "You are within your budget."
        End If
        If currentSavings >= savingsGoal Then
            result.SavingsStatus = "Savings goal achieved."
        Else
            result.SavingsStatus = "Amount still needed: BZ$ " & result.SavingsNeeded.ToString("N2", CultureInfo.InvariantCulture)
        End If
        Return result
    End Function

    Public Sub Reset()
        TotalAllowance = 0D
        TotalExtraMoney = 0D
        TotalGiftMoney = 0D
        TotalOtherIncome = 0D
        entries.Clear()
    End Sub

    Private Shared Sub ValidateAmount(value As Decimal)
        If value < 0D OrElse value > MoneyInput.MaximumEntry OrElse Decimal.Round(value, 2) <> value Then
            Throw New ArgumentException("Use 0 to 1,000,000 with at most two decimal places.")
        End If
    End Sub
End Class
