<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim expenseAmountCellStyle As New System.Windows.Forms.DataGridViewCellStyle()
        Me.SuspendLayout()
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular)
        Me.ClientSize = New System.Drawing.Size(1040, 680)
        Me.headerPanel = New System.Windows.Forms.Panel()
        Me.headerPanel.Name = "headerPanel"
        Me.headerPanel.Text = ""
        Me.headerPanel.Location = New System.Drawing.Point(0, 0)
        Me.headerPanel.Size = New System.Drawing.Size(1040, 88)
        Me.headerPanel.Anchor = System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        Me.headerPanel.BackColor = System.Drawing.Color.FromArgb(204, 225, 250)
        Me.Controls.Add(Me.headerPanel)
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Text = "BudgetBuddy"
        Me.lblTitle.Location = New System.Drawing.Point(100, 10)
        Me.lblTitle.Size = New System.Drawing.Size(600, 43)
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 23.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(13, 38, 77)
        Me.headerPanel.Controls.Add(Me.lblTitle)
        Me.lblSubtitle = New System.Windows.Forms.Label()
        Me.lblSubtitle.Name = "lblSubtitle"
        Me.lblSubtitle.Text = "Student Allowance and Spending Management System"
        Me.lblSubtitle.Location = New System.Drawing.Point(102, 55)
        Me.lblSubtitle.Size = New System.Drawing.Size(760, 23)
        Me.lblSubtitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSubtitle.AutoSize = True
        Me.lblSubtitle.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.headerPanel.Controls.Add(Me.lblSubtitle)
        Me.grpIncome = New System.Windows.Forms.Panel()
        Me.grpIncome.Name = "grpIncome"
        Me.grpIncome.Text = ""
        Me.grpIncome.Location = New System.Drawing.Point(14, 102)
        Me.grpIncome.Size = New System.Drawing.Size(314, 272)
        Me.grpIncome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.grpIncome.BackColor = System.Drawing.Color.FromArgb(250, 252, 255)
        Me.Controls.Add(Me.grpIncome)
        Me.grpIncomeHeading = New System.Windows.Forms.Label()
        Me.grpIncomeHeading.Name = "grpIncomeHeading"
        Me.grpIncomeHeading.Text = "Income"
        Me.grpIncomeHeading.Location = New System.Drawing.Point(0, 0)
        Me.grpIncomeHeading.Size = New System.Drawing.Size(312, 28)
        Me.grpIncomeHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpIncomeHeading.BackColor = System.Drawing.Color.FromArgb(213, 232, 254)
        Me.grpIncomeHeading.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.grpIncomeHeading.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.grpIncome.Controls.Add(Me.grpIncomeHeading)
        Me.grpExpense = New System.Windows.Forms.Panel()
        Me.grpExpense.Name = "grpExpense"
        Me.grpExpense.Text = ""
        Me.grpExpense.Location = New System.Drawing.Point(340, 102)
        Me.grpExpense.Size = New System.Drawing.Size(354, 272)
        Me.grpExpense.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.grpExpense.BackColor = System.Drawing.Color.FromArgb(250, 252, 255)
        Me.Controls.Add(Me.grpExpense)
        Me.grpExpenseHeading = New System.Windows.Forms.Label()
        Me.grpExpenseHeading.Name = "grpExpenseHeading"
        Me.grpExpenseHeading.Text = "Expenses"
        Me.grpExpenseHeading.Location = New System.Drawing.Point(0, 0)
        Me.grpExpenseHeading.Size = New System.Drawing.Size(352, 28)
        Me.grpExpenseHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpExpenseHeading.BackColor = System.Drawing.Color.FromArgb(216, 240, 229)
        Me.grpExpenseHeading.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.grpExpenseHeading.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.grpExpense.Controls.Add(Me.grpExpenseHeading)
        Me.grpSavings = New System.Windows.Forms.Panel()
        Me.grpSavings.Name = "grpSavings"
        Me.grpSavings.Text = ""
        Me.grpSavings.Location = New System.Drawing.Point(706, 102)
        Me.grpSavings.Size = New System.Drawing.Size(320, 272)
        Me.grpSavings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.grpSavings.BackColor = System.Drawing.Color.FromArgb(250, 252, 255)
        Me.Controls.Add(Me.grpSavings)
        Me.grpSavingsHeading = New System.Windows.Forms.Label()
        Me.grpSavingsHeading.Name = "grpSavingsHeading"
        Me.grpSavingsHeading.Text = "Savings"
        Me.grpSavingsHeading.Location = New System.Drawing.Point(0, 0)
        Me.grpSavingsHeading.Size = New System.Drawing.Size(318, 28)
        Me.grpSavingsHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSavingsHeading.BackColor = System.Drawing.Color.FromArgb(229, 222, 252)
        Me.grpSavingsHeading.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.grpSavingsHeading.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.grpSavings.Controls.Add(Me.grpSavingsHeading)
        Me.lblAllowance = New System.Windows.Forms.Label()
        Me.lblAllowance.Name = "lblAllowance"
        Me.lblAllowance.Text = "Allowance (Weekly/Monthly):"
        Me.lblAllowance.Location = New System.Drawing.Point(10, 43)
        Me.lblAllowance.Size = New System.Drawing.Size(168, 26)
        Me.lblAllowance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAllowance.Font = New System.Drawing.Font("Segoe UI", 8.5!)
        Me.grpIncome.Controls.Add(Me.lblAllowance)
        Me.txtAllowance = New System.Windows.Forms.TextBox()
        Me.txtAllowance.Name = "txtAllowance"
        Me.txtAllowance.Text = ""
        Me.txtAllowance.Location = New System.Drawing.Point(180, 44)
        Me.txtAllowance.Size = New System.Drawing.Size(120, 25)
        Me.txtAllowance.MaxLength = 20
        Me.txtAllowance.TabIndex = 0
        Me.grpIncome.Controls.Add(Me.txtAllowance)
        Me.lblExtraMoney = New System.Windows.Forms.Label()
        Me.lblExtraMoney.Name = "lblExtraMoney"
        Me.lblExtraMoney.Text = "Extra Money Received:"
        Me.lblExtraMoney.Location = New System.Drawing.Point(10, 80)
        Me.lblExtraMoney.Size = New System.Drawing.Size(168, 26)
        Me.lblExtraMoney.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpIncome.Controls.Add(Me.lblExtraMoney)
        Me.txtExtraMoney = New System.Windows.Forms.TextBox()
        Me.txtExtraMoney.Name = "txtExtraMoney"
        Me.txtExtraMoney.Text = ""
        Me.txtExtraMoney.Location = New System.Drawing.Point(180, 81)
        Me.txtExtraMoney.Size = New System.Drawing.Size(120, 25)
        Me.txtExtraMoney.MaxLength = 20
        Me.txtExtraMoney.TabIndex = 1
        Me.grpIncome.Controls.Add(Me.txtExtraMoney)
        Me.lblGiftMoney = New System.Windows.Forms.Label()
        Me.lblGiftMoney.Name = "lblGiftMoney"
        Me.lblGiftMoney.Text = "Gift Money:"
        Me.lblGiftMoney.Location = New System.Drawing.Point(10, 117)
        Me.lblGiftMoney.Size = New System.Drawing.Size(168, 26)
        Me.lblGiftMoney.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpIncome.Controls.Add(Me.lblGiftMoney)
        Me.txtGiftMoney = New System.Windows.Forms.TextBox()
        Me.txtGiftMoney.Name = "txtGiftMoney"
        Me.txtGiftMoney.Text = ""
        Me.txtGiftMoney.Location = New System.Drawing.Point(180, 118)
        Me.txtGiftMoney.Size = New System.Drawing.Size(120, 25)
        Me.txtGiftMoney.MaxLength = 20
        Me.txtGiftMoney.TabIndex = 2
        Me.grpIncome.Controls.Add(Me.txtGiftMoney)
        Me.lblOtherIncome = New System.Windows.Forms.Label()
        Me.lblOtherIncome.Name = "lblOtherIncome"
        Me.lblOtherIncome.Text = "Other Income:"
        Me.lblOtherIncome.Location = New System.Drawing.Point(10, 154)
        Me.lblOtherIncome.Size = New System.Drawing.Size(168, 26)
        Me.lblOtherIncome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpIncome.Controls.Add(Me.lblOtherIncome)
        Me.txtOtherIncome = New System.Windows.Forms.TextBox()
        Me.txtOtherIncome.Name = "txtOtherIncome"
        Me.txtOtherIncome.Text = ""
        Me.txtOtherIncome.Location = New System.Drawing.Point(180, 155)
        Me.txtOtherIncome.Size = New System.Drawing.Size(120, 25)
        Me.txtOtherIncome.MaxLength = 20
        Me.txtOtherIncome.TabIndex = 3
        Me.grpIncome.Controls.Add(Me.txtOtherIncome)
        Me.btnAddIncome = New System.Windows.Forms.Button()
        Me.btnAddIncome.Name = "btnAddIncome"
        Me.btnAddIncome.Text = "Add Income"
        Me.btnAddIncome.Location = New System.Drawing.Point(180, 197)
        Me.btnAddIncome.Size = New System.Drawing.Size(120, 29)
        Me.btnAddIncome.TabIndex = 4
        Me.btnAddIncome.UseVisualStyleBackColor = False
        Me.btnAddIncome.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.grpIncome.Controls.Add(Me.btnAddIncome)
        Me.lblIncomeHint = New System.Windows.Forms.Label()
        Me.lblIncomeHint.Name = "lblIncomeHint"
        Me.lblIncomeHint.Text = "Enter amounts, then click Add Income."
        Me.lblIncomeHint.Location = New System.Drawing.Point(10, 237)
        Me.lblIncomeHint.Size = New System.Drawing.Size(290, 22)
        Me.lblIncomeHint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblIncomeHint.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.lblIncomeHint.ForeColor = System.Drawing.Color.FromArgb(80, 97, 115)
        Me.grpIncome.Controls.Add(Me.lblIncomeHint)
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Text = "Category:"
        Me.lblCategory.Location = New System.Drawing.Point(12, 41)
        Me.lblCategory.Size = New System.Drawing.Size(70, 25)
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpExpense.Controls.Add(Me.lblCategory)
        Me.cboExpenseCategory = New System.Windows.Forms.ComboBox()
        Me.cboExpenseCategory.Name = "cboExpenseCategory"
        Me.cboExpenseCategory.Text = ""
        Me.cboExpenseCategory.Location = New System.Drawing.Point(86, 42)
        Me.cboExpenseCategory.Size = New System.Drawing.Size(250, 26)
        Me.cboExpenseCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboExpenseCategory.TabIndex = 0
        Me.grpExpense.Controls.Add(Me.cboExpenseCategory)
        Me.cboExpenseCategory.Items.AddRange(New Object() {"Food & Snacks", "Transportation", "School Supplies", "Entertainment", "Games/Applications", "Other Expenses"})
        Me.lblExpenseAmount = New System.Windows.Forms.Label()
        Me.lblExpenseAmount.Name = "lblExpenseAmount"
        Me.lblExpenseAmount.Text = "Amount:"
        Me.lblExpenseAmount.Location = New System.Drawing.Point(12, 78)
        Me.lblExpenseAmount.Size = New System.Drawing.Size(70, 25)
        Me.lblExpenseAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpExpense.Controls.Add(Me.lblExpenseAmount)
        Me.txtExpenseAmount = New System.Windows.Forms.TextBox()
        Me.txtExpenseAmount.Name = "txtExpenseAmount"
        Me.txtExpenseAmount.Text = ""
        Me.txtExpenseAmount.Location = New System.Drawing.Point(86, 79)
        Me.txtExpenseAmount.Size = New System.Drawing.Size(250, 25)
        Me.txtExpenseAmount.MaxLength = 20
        Me.txtExpenseAmount.TabIndex = 1
        Me.grpExpense.Controls.Add(Me.txtExpenseAmount)
        Me.btnAddExpense = New System.Windows.Forms.Button()
        Me.btnAddExpense.Name = "btnAddExpense"
        Me.btnAddExpense.Text = "Add Expense"
        Me.btnAddExpense.Location = New System.Drawing.Point(226, 112)
        Me.btnAddExpense.Size = New System.Drawing.Size(110, 29)
        Me.btnAddExpense.TabIndex = 2
        Me.btnAddExpense.UseVisualStyleBackColor = False
        Me.btnAddExpense.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.grpExpense.Controls.Add(Me.btnAddExpense)
        Me.lstExpenses = New System.Windows.Forms.DataGridView()
        Me.colExpenseCategory = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExpenseAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.lstExpenses, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.lstExpenses.Name = "lstExpenses"
        Me.lstExpenses.Text = ""
        Me.lstExpenses.Location = New System.Drawing.Point(12, 151)
        Me.lstExpenses.Size = New System.Drawing.Size(240, 108)
        Me.lstExpenses.AllowUserToAddRows = False
        Me.lstExpenses.AllowUserToDeleteRows = False
        Me.lstExpenses.AllowUserToResizeRows = False
        Me.lstExpenses.ReadOnly = True
        Me.lstExpenses.RowHeadersVisible = False
        Me.lstExpenses.ColumnHeadersVisible = True
        Me.lstExpenses.MultiSelect = False
        Me.lstExpenses.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.lstExpenses.AutoGenerateColumns = False
        Me.lstExpenses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.lstExpenses.BackgroundColor = System.Drawing.Color.White
        Me.lstExpenses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstExpenses.TabIndex = 3
        Me.grpExpense.Controls.Add(Me.lstExpenses)
        Me.colExpenseCategory.Name = "Category"
        Me.colExpenseCategory.HeaderText = "Category"
        Me.colExpenseCategory.FillWeight = 66.0!
        Me.colExpenseCategory.ReadOnly = True
        Me.colExpenseCategory.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExpenseAmount.Name = "Amount"
        Me.colExpenseAmount.HeaderText = "Amount"
        Me.colExpenseAmount.FillWeight = 34.0!
        Me.colExpenseAmount.ReadOnly = True
        Me.colExpenseAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        expenseAmountCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExpenseAmount.DefaultCellStyle = expenseAmountCellStyle
        Me.lstExpenses.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colExpenseCategory, Me.colExpenseAmount})
        Me.btnRemoveExpense = New System.Windows.Forms.Button()
        Me.btnRemoveExpense.Name = "btnRemoveExpense"
        Me.btnRemoveExpense.Text = "Remove"
        Me.btnRemoveExpense.Location = New System.Drawing.Point(261, 172)
        Me.btnRemoveExpense.Size = New System.Drawing.Size(75, 29)
        Me.btnRemoveExpense.TabIndex = 4
        Me.btnRemoveExpense.UseVisualStyleBackColor = False
        Me.btnRemoveExpense.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.grpExpense.Controls.Add(Me.btnRemoveExpense)
        Me.lblCurrentSavings = New System.Windows.Forms.Label()
        Me.lblCurrentSavings.Name = "lblCurrentSavings"
        Me.lblCurrentSavings.Text = "Current Savings:"
        Me.lblCurrentSavings.Location = New System.Drawing.Point(14, 48)
        Me.lblCurrentSavings.Size = New System.Drawing.Size(122, 28)
        Me.lblCurrentSavings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSavings.Controls.Add(Me.lblCurrentSavings)
        Me.txtCurrentSavings = New System.Windows.Forms.TextBox()
        Me.txtCurrentSavings.Name = "txtCurrentSavings"
        Me.txtCurrentSavings.Text = ""
        Me.txtCurrentSavings.Location = New System.Drawing.Point(142, 50)
        Me.txtCurrentSavings.Size = New System.Drawing.Size(162, 25)
        Me.txtCurrentSavings.MaxLength = 20
        Me.txtCurrentSavings.TabIndex = 0
        Me.grpSavings.Controls.Add(Me.txtCurrentSavings)
        Me.lblSavingsGoal = New System.Windows.Forms.Label()
        Me.lblSavingsGoal.Name = "lblSavingsGoal"
        Me.lblSavingsGoal.Text = "Savings Goal:"
        Me.lblSavingsGoal.Location = New System.Drawing.Point(14, 97)
        Me.lblSavingsGoal.Size = New System.Drawing.Size(122, 28)
        Me.lblSavingsGoal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSavings.Controls.Add(Me.lblSavingsGoal)
        Me.txtSavingsGoal = New System.Windows.Forms.TextBox()
        Me.txtSavingsGoal.Name = "txtSavingsGoal"
        Me.txtSavingsGoal.Text = ""
        Me.txtSavingsGoal.Location = New System.Drawing.Point(142, 99)
        Me.txtSavingsGoal.Size = New System.Drawing.Size(162, 25)
        Me.txtSavingsGoal.MaxLength = 20
        Me.txtSavingsGoal.TabIndex = 1
        Me.grpSavings.Controls.Add(Me.txtSavingsGoal)
        Me.lblSavingsProgress = New System.Windows.Forms.Label()
        Me.lblSavingsProgress.Name = "lblSavingsProgress"
        Me.lblSavingsProgress.Text = "Savings progress: not checked"
        Me.lblSavingsProgress.Location = New System.Drawing.Point(14, 153)
        Me.lblSavingsProgress.Size = New System.Drawing.Size(290, 23)
        Me.lblSavingsProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSavingsProgress.ForeColor = System.Drawing.Color.FromArgb(77, 67, 113)
        Me.grpSavings.Controls.Add(Me.lblSavingsProgress)
        Me.prgSavings = New System.Windows.Forms.ProgressBar()
        Me.prgSavings.Name = "prgSavings"
        Me.prgSavings.Text = ""
        Me.prgSavings.Location = New System.Drawing.Point(14, 181)
        Me.prgSavings.Size = New System.Drawing.Size(290, 16)
        Me.grpSavings.Controls.Add(Me.prgSavings)
        Me.lblNumberHint = New System.Windows.Forms.Label()
        Me.lblNumberHint.Name = "lblNumberHint"
        Me.lblNumberHint.Text = "Enter amounts such as 125.50."
        Me.lblNumberHint.Location = New System.Drawing.Point(14, 211)
        Me.lblNumberHint.Size = New System.Drawing.Size(290, 20)
        Me.lblNumberHint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblNumberHint.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.lblNumberHint.ForeColor = System.Drawing.Color.FromArgb(80, 97, 115)
        Me.grpSavings.Controls.Add(Me.lblNumberHint)
        Me.lblSavingsNote = New System.Windows.Forms.Label()
        Me.lblSavingsNote.Name = "lblSavingsNote"
        Me.lblSavingsNote.Text = "Savings are separate from spending money."
        Me.lblSavingsNote.Location = New System.Drawing.Point(14, 238)
        Me.lblSavingsNote.Size = New System.Drawing.Size(290, 20)
        Me.lblSavingsNote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSavingsNote.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.lblSavingsNote.ForeColor = System.Drawing.Color.FromArgb(80, 97, 115)
        Me.grpSavings.Controls.Add(Me.lblSavingsNote)
        Me.grpSummary = New System.Windows.Forms.Panel()
        Me.grpSummary.Name = "grpSummary"
        Me.grpSummary.Text = ""
        Me.grpSummary.Location = New System.Drawing.Point(14, 388)
        Me.grpSummary.Size = New System.Drawing.Size(1012, 218)
        Me.grpSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.grpSummary.BackColor = System.Drawing.Color.FromArgb(250, 251, 254)
        Me.Controls.Add(Me.grpSummary)
        Me.grpSummaryHeading = New System.Windows.Forms.Label()
        Me.grpSummaryHeading.Name = "grpSummaryHeading"
        Me.grpSummaryHeading.Text = "Budget Summary"
        Me.grpSummaryHeading.Location = New System.Drawing.Point(0, 0)
        Me.grpSummaryHeading.Size = New System.Drawing.Size(1010, 28)
        Me.grpSummaryHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummaryHeading.BackColor = System.Drawing.Color.FromArgb(242, 224, 234)
        Me.grpSummaryHeading.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.grpSummaryHeading.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.grpSummary.Controls.Add(Me.grpSummaryHeading)
        Me.lblTotalAvailableCaption = New System.Windows.Forms.Label()
        Me.lblTotalAvailableCaption.Name = "lblTotalAvailableCaption"
        Me.lblTotalAvailableCaption.Text = "Total Income:"
        Me.lblTotalAvailableCaption.Location = New System.Drawing.Point(16, 39)
        Me.lblTotalAvailableCaption.Size = New System.Drawing.Size(220, 26)
        Me.lblTotalAvailableCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblTotalAvailableCaption)
        Me.lblTotalAvailable = New System.Windows.Forms.Label()
        Me.lblTotalAvailable.Name = "lblTotalAvailable"
        Me.lblTotalAvailable.Text = "BZ$ 0.00"
        Me.lblTotalAvailable.Location = New System.Drawing.Point(242, 39)
        Me.lblTotalAvailable.Size = New System.Drawing.Size(220, 26)
        Me.lblTotalAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblTotalAvailable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalAvailable.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblTotalAvailable.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblTotalAvailable)
        Me.lblTotalExpensesCaption = New System.Windows.Forms.Label()
        Me.lblTotalExpensesCaption.Name = "lblTotalExpensesCaption"
        Me.lblTotalExpensesCaption.Text = "Total Expenses:"
        Me.lblTotalExpensesCaption.Location = New System.Drawing.Point(16, 72)
        Me.lblTotalExpensesCaption.Size = New System.Drawing.Size(220, 26)
        Me.lblTotalExpensesCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblTotalExpensesCaption)
        Me.lblTotalExpenses = New System.Windows.Forms.Label()
        Me.lblTotalExpenses.Name = "lblTotalExpenses"
        Me.lblTotalExpenses.Text = "BZ$ 0.00"
        Me.lblTotalExpenses.Location = New System.Drawing.Point(242, 72)
        Me.lblTotalExpenses.Size = New System.Drawing.Size(220, 26)
        Me.lblTotalExpenses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblTotalExpenses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalExpenses.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblTotalExpenses.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblTotalExpenses)
        Me.lblRemainingBalanceCaption = New System.Windows.Forms.Label()
        Me.lblRemainingBalanceCaption.Name = "lblRemainingBalanceCaption"
        Me.lblRemainingBalanceCaption.Text = "Remaining Balance:"
        Me.lblRemainingBalanceCaption.Location = New System.Drawing.Point(16, 105)
        Me.lblRemainingBalanceCaption.Size = New System.Drawing.Size(220, 26)
        Me.lblRemainingBalanceCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblRemainingBalanceCaption)
        Me.lblRemainingBalance = New System.Windows.Forms.Label()
        Me.lblRemainingBalance.Name = "lblRemainingBalance"
        Me.lblRemainingBalance.Text = "BZ$ 0.00"
        Me.lblRemainingBalance.Location = New System.Drawing.Point(242, 105)
        Me.lblRemainingBalance.Size = New System.Drawing.Size(220, 26)
        Me.lblRemainingBalance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblRemainingBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRemainingBalance.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblRemainingBalance.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblRemainingBalance)
        Me.lblAmountSavedCaption = New System.Windows.Forms.Label()
        Me.lblAmountSavedCaption.Name = "lblAmountSavedCaption"
        Me.lblAmountSavedCaption.Text = "Amount Saved:"
        Me.lblAmountSavedCaption.Location = New System.Drawing.Point(16, 138)
        Me.lblAmountSavedCaption.Size = New System.Drawing.Size(220, 26)
        Me.lblAmountSavedCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblAmountSavedCaption)
        Me.lblAmountSaved = New System.Windows.Forms.Label()
        Me.lblAmountSaved.Name = "lblAmountSaved"
        Me.lblAmountSaved.Text = "BZ$ 0.00"
        Me.lblAmountSaved.Location = New System.Drawing.Point(242, 138)
        Me.lblAmountSaved.Size = New System.Drawing.Size(220, 26)
        Me.lblAmountSaved.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAmountSaved.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAmountSaved.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblAmountSaved.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblAmountSaved)
        Me.lblSavingsNeededCaption = New System.Windows.Forms.Label()
        Me.lblSavingsNeededCaption.Name = "lblSavingsNeededCaption"
        Me.lblSavingsNeededCaption.Text = "Amount Needed to Reach Goal:"
        Me.lblSavingsNeededCaption.Location = New System.Drawing.Point(16, 171)
        Me.lblSavingsNeededCaption.Size = New System.Drawing.Size(220, 26)
        Me.lblSavingsNeededCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblSavingsNeededCaption)
        Me.lblSavingsNeeded = New System.Windows.Forms.Label()
        Me.lblSavingsNeeded.Name = "lblSavingsNeeded"
        Me.lblSavingsNeeded.Text = "BZ$ 0.00"
        Me.lblSavingsNeeded.Location = New System.Drawing.Point(242, 171)
        Me.lblSavingsNeeded.Size = New System.Drawing.Size(220, 26)
        Me.lblSavingsNeeded.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSavingsNeeded.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSavingsNeeded.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblSavingsNeeded.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblSavingsNeeded)
        Me.lblSpendingPercentageCaption = New System.Windows.Forms.Label()
        Me.lblSpendingPercentageCaption.Name = "lblSpendingPercentageCaption"
        Me.lblSpendingPercentageCaption.Text = "Spending Percentage:"
        Me.lblSpendingPercentageCaption.Location = New System.Drawing.Point(500, 44)
        Me.lblSpendingPercentageCaption.Size = New System.Drawing.Size(170, 27)
        Me.lblSpendingPercentageCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblSpendingPercentageCaption)
        Me.lblSpendingPercentage = New System.Windows.Forms.Label()
        Me.lblSpendingPercentage.Name = "lblSpendingPercentage"
        Me.lblSpendingPercentage.Text = "0%"
        Me.lblSpendingPercentage.Location = New System.Drawing.Point(682, 44)
        Me.lblSpendingPercentage.Size = New System.Drawing.Size(304, 27)
        Me.lblSpendingPercentage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblSpendingPercentage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpendingPercentage.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.lblSpendingPercentage.Padding = New System.Windows.Forms.Padding(7, 0, 0, 0)
        Me.grpSummary.Controls.Add(Me.lblSpendingPercentage)
        Me.lblBudgetStatusCaption = New System.Windows.Forms.Label()
        Me.lblBudgetStatusCaption.Name = "lblBudgetStatusCaption"
        Me.lblBudgetStatusCaption.Text = "Budget Status:"
        Me.lblBudgetStatusCaption.Location = New System.Drawing.Point(500, 88)
        Me.lblBudgetStatusCaption.Size = New System.Drawing.Size(170, 22)
        Me.lblBudgetStatusCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblBudgetStatusCaption)
        Me.lblBudgetStatus = New System.Windows.Forms.Label()
        Me.lblBudgetStatus.Name = "lblBudgetStatus"
        Me.lblBudgetStatus.Text = "Not Calculated"
        Me.lblBudgetStatus.Location = New System.Drawing.Point(500, 116)
        Me.lblBudgetStatus.Size = New System.Drawing.Size(486, 36)
        Me.lblBudgetStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblBudgetStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBudgetStatus.BackColor = System.Drawing.Color.FromArgb(235, 240, 247)
        Me.grpSummary.Controls.Add(Me.lblBudgetStatus)
        Me.lblSavingsStatusCaption = New System.Windows.Forms.Label()
        Me.lblSavingsStatusCaption.Name = "lblSavingsStatusCaption"
        Me.lblSavingsStatusCaption.Text = "Savings Status:"
        Me.lblSavingsStatusCaption.Location = New System.Drawing.Point(500, 169)
        Me.lblSavingsStatusCaption.Size = New System.Drawing.Size(110, 26)
        Me.lblSavingsStatusCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblSavingsStatusCaption)
        Me.lblSavingsStatus = New System.Windows.Forms.Label()
        Me.lblSavingsStatus.Name = "lblSavingsStatus"
        Me.lblSavingsStatus.Text = "Savings goal not checked"
        Me.lblSavingsStatus.Location = New System.Drawing.Point(612, 167)
        Me.lblSavingsStatus.Size = New System.Drawing.Size(374, 36)
        Me.lblSavingsStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.grpSummary.Controls.Add(Me.lblSavingsStatus)
        Me.footerPanel = New System.Windows.Forms.Panel()
        Me.footerPanel.Name = "footerPanel"
        Me.footerPanel.Text = ""
        Me.footerPanel.Location = New System.Drawing.Point(14, 620)
        Me.footerPanel.Size = New System.Drawing.Size(1012, 46)
        Me.footerPanel.BackColor = System.Drawing.Color.FromArgb(221, 234, 250)
        Me.Controls.Add(Me.footerPanel)
        Me.lblFeedback = New System.Windows.Forms.Label()
        Me.lblFeedback.Name = "lblFeedback"
        Me.lblFeedback.Text = "Ready. Enter your income and expenses."
        Me.lblFeedback.Location = New System.Drawing.Point(12, 5)
        Me.lblFeedback.Size = New System.Drawing.Size(620, 35)
        Me.lblFeedback.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblFeedback.Font = New System.Drawing.Font("Segoe UI", 8.5!)
        Me.lblFeedback.ForeColor = System.Drawing.Color.FromArgb(40, 66, 95)
        Me.footerPanel.Controls.Add(Me.lblFeedback)
        Me.btnViewBudget = New System.Windows.Forms.Button()
        Me.btnViewBudget.Name = "btnViewBudget"
        Me.btnViewBudget.Text = "Calculate"
        Me.btnViewBudget.Location = New System.Drawing.Point(658, 8)
        Me.btnViewBudget.Size = New System.Drawing.Size(118, 29)
        Me.btnViewBudget.TabIndex = 0
        Me.btnViewBudget.UseVisualStyleBackColor = False
        Me.btnViewBudget.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.footerPanel.Controls.Add(Me.btnViewBudget)
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Text = "Reset"
        Me.btnReset.Location = New System.Drawing.Point(786, 8)
        Me.btnReset.Size = New System.Drawing.Size(100, 29)
        Me.btnReset.TabIndex = 1
        Me.btnReset.UseVisualStyleBackColor = False
        Me.btnReset.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.footerPanel.Controls.Add(Me.btnReset)
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Text = "Exit"
        Me.btnExit.Location = New System.Drawing.Point(896, 8)
        Me.btnExit.Size = New System.Drawing.Size(100, 29)
        Me.btnExit.TabIndex = 2
        Me.btnExit.UseVisualStyleBackColor = False
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(231, 239, 249)
        Me.footerPanel.Controls.Add(Me.btnExit)
        Me.AutoScroll = True
        Me.AutoScrollMinSize = New System.Drawing.Size(1040, 680)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Name = "MainForm"
        Me.Text = "BudgetBuddy"
        Me.BackColor = System.Drawing.Color.FromArgb(244, 248, 253)
        CType(Me.lstExpenses, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub

    Friend WithEvents headerPanel As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblSubtitle As System.Windows.Forms.Label
    Friend WithEvents grpIncome As System.Windows.Forms.Panel
    Friend WithEvents grpIncomeHeading As System.Windows.Forms.Label
    Friend WithEvents grpExpense As System.Windows.Forms.Panel
    Friend WithEvents grpExpenseHeading As System.Windows.Forms.Label
    Friend WithEvents grpSavings As System.Windows.Forms.Panel
    Friend WithEvents grpSavingsHeading As System.Windows.Forms.Label
    Friend WithEvents lblAllowance As System.Windows.Forms.Label
    Friend WithEvents txtAllowance As System.Windows.Forms.TextBox
    Friend WithEvents lblExtraMoney As System.Windows.Forms.Label
    Friend WithEvents txtExtraMoney As System.Windows.Forms.TextBox
    Friend WithEvents lblGiftMoney As System.Windows.Forms.Label
    Friend WithEvents txtGiftMoney As System.Windows.Forms.TextBox
    Friend WithEvents lblOtherIncome As System.Windows.Forms.Label
    Friend WithEvents txtOtherIncome As System.Windows.Forms.TextBox
    Friend WithEvents btnAddIncome As System.Windows.Forms.Button
    Friend WithEvents lblIncomeHint As System.Windows.Forms.Label
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents cboExpenseCategory As System.Windows.Forms.ComboBox
    Friend WithEvents lblExpenseAmount As System.Windows.Forms.Label
    Friend WithEvents txtExpenseAmount As System.Windows.Forms.TextBox
    Friend WithEvents btnAddExpense As System.Windows.Forms.Button
    Friend WithEvents lstExpenses As System.Windows.Forms.DataGridView
    Friend WithEvents colExpenseCategory As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExpenseAmount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnRemoveExpense As System.Windows.Forms.Button
    Friend WithEvents lblCurrentSavings As System.Windows.Forms.Label
    Friend WithEvents txtCurrentSavings As System.Windows.Forms.TextBox
    Friend WithEvents lblSavingsGoal As System.Windows.Forms.Label
    Friend WithEvents txtSavingsGoal As System.Windows.Forms.TextBox
    Friend WithEvents lblSavingsProgress As System.Windows.Forms.Label
    Friend WithEvents prgSavings As System.Windows.Forms.ProgressBar
    Friend WithEvents lblNumberHint As System.Windows.Forms.Label
    Friend WithEvents lblSavingsNote As System.Windows.Forms.Label
    Friend WithEvents grpSummary As System.Windows.Forms.Panel
    Friend WithEvents grpSummaryHeading As System.Windows.Forms.Label
    Friend WithEvents lblTotalAvailableCaption As System.Windows.Forms.Label
    Friend WithEvents lblTotalAvailable As System.Windows.Forms.Label
    Friend WithEvents lblTotalExpensesCaption As System.Windows.Forms.Label
    Friend WithEvents lblTotalExpenses As System.Windows.Forms.Label
    Friend WithEvents lblRemainingBalanceCaption As System.Windows.Forms.Label
    Friend WithEvents lblRemainingBalance As System.Windows.Forms.Label
    Friend WithEvents lblAmountSavedCaption As System.Windows.Forms.Label
    Friend WithEvents lblAmountSaved As System.Windows.Forms.Label
    Friend WithEvents lblSavingsNeededCaption As System.Windows.Forms.Label
    Friend WithEvents lblSavingsNeeded As System.Windows.Forms.Label
    Friend WithEvents lblSpendingPercentageCaption As System.Windows.Forms.Label
    Friend WithEvents lblSpendingPercentage As System.Windows.Forms.Label
    Friend WithEvents lblBudgetStatusCaption As System.Windows.Forms.Label
    Friend WithEvents lblBudgetStatus As System.Windows.Forms.Label
    Friend WithEvents lblSavingsStatusCaption As System.Windows.Forms.Label
    Friend WithEvents lblSavingsStatus As System.Windows.Forms.Label
    Friend WithEvents footerPanel As System.Windows.Forms.Panel
    Friend WithEvents lblFeedback As System.Windows.Forms.Label
    Friend WithEvents btnViewBudget As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
End Class
