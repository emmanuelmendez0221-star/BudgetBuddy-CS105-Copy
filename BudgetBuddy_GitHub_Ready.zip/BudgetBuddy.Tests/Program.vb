Imports System.Globalization

Module Program
    Private passed As Integer
    Private failed As Integer

    Sub Main()
        Console.WriteLine("BudgetBuddy VB logic checks - actual BudgetLogic.vb linked into net10.0 console project")
        Console.WriteLine("Environment: " & Environment.OSVersion.ToString())
        Dim ledger As New BudgetLedger()
        Dim result = ledger.Calculate(0D, 100D)
        Check("Zero income percentage is Nothing", Not result.SpendingPercentage.HasValue)
        Check("Zero income instruction", result.BudgetStatus = "Enter income to calculate your budget.")
        ledger.AddIncome(100D, 20D)
        ledger.AddExpense("Food & Snacks", 30D)
        result = ledger.Calculate(25D, 100D)
        Check("Available = 120", result.TotalAvailable = 120D)
        Check("Expenses = 30", result.TotalExpenses = 30D)
        Check("Remaining = 90", result.RemainingBalance = 90D)
        Check("Spent = 25 percent", result.SpendingPercentage.HasValue AndAlso result.SpendingPercentage.GetValueOrDefault() = 25D)
        Check("Savings needed = 75", result.SavingsNeeded = 75D)
        Check("Within-budget decision", result.BudgetStatus = "You are within your budget.")
        Check("Savings below goal", result.SavingsStatus = "Amount still needed: BZ$ 75.00")
        ledger.Reset()
        ledger.AddIncome(100D, 0D)
        ledger.AddExpense("Transportation", 79.99D)
        Check("79.99 percent below warning", ledger.Calculate(0D, 0D).BudgetStatus = "You are within your budget.")
        ledger.AddExpense("Transportation", 0.01D)
        Check("80 percent warning boundary", ledger.Calculate(0D, 0D).BudgetStatus.StartsWith("Warning:"))
        ledger.AddExpense("Other Expenses", 20D)
        Check("Exactly 100 percent still warning", ledger.Calculate(0D, 0D).BudgetStatus.StartsWith("Warning:"))
        ledger.AddExpense("Other Expenses", 0.01D)
        result = ledger.Calculate(120D, 100D)
        Check("Over-budget priority", result.BudgetStatus = "You have exceeded your available budget.")
        Check("Negative balance retained", result.RemainingBalance = -0.01D)
        Check("Savings surplus clamps to zero", result.SavingsNeeded = 0D)
        Check("Savings achieved decision", result.SavingsStatus = "Savings goal achieved.")
        Check("Exact savings goal achieved", ledger.Calculate(100D, 100D).SavingsStatus = "Savings goal achieved.")
        Check("Zero savings goal achieved", ledger.Calculate(0D, 0D).SavingsStatus = "Savings goal achieved.")
        ledger.Reset()
        ledger.AddExpense("School Supplies", 5D)
        result = ledger.Calculate(0D, 0D)
        Check("Expense with zero income over budget", result.BudgetStatus = "You have exceeded your available budget.")
        Check("Expense with zero income no division", Not result.SpendingPercentage.HasValue)
        ledger.Reset()
        ledger.AddIncome(0.1D, 0.2D)
        Check("Decimal money 0.10 + 0.20", ledger.TotalIncome = 0.3D)
        ledger.AddIncome(10D, 1D)
        Check("Multiple income entries accumulate", ledger.TotalIncome = 11.3D)
        Dim amount As Decimal
        Check("Plain decimal accepted", MoneyInput.TryRead("125.50", False, amount) AndAlso amount = 125.5D)
        Check("Optional blank is zero", MoneyInput.TryRead("", True, amount) AndAlso amount = 0D)
        Check("Required blank rejected", Not MoneyInput.TryRead("", False, amount))
        For Each invalid In New String() {"abc", "-1", "$12", "1,000", "1.234", "1000000.01", "1E3", "999999999999999999999999999999999999"}
            Check("Reject invalid input: " & invalid, Not MoneyInput.TryRead(invalid, False, amount))
        Next
        Check("Maximum entry accepted", MoneyInput.TryRead("1000000.00", False, amount))
        CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR")
        Check("Dot format independent of PC locale", MoneyInput.TryRead("12.50", False, amount) AndAlso amount = 12.5D)
        Rejects("Reject zero income", Sub() ledger.AddIncome(0D, 0D))
        Rejects("Reject negative income", Sub() ledger.AddIncome(-1D, 0D))
        Rejects("Reject zero expense", Sub() ledger.AddExpense("Food & Snacks", 0D))
        Rejects("Reject negative expense", Sub() ledger.AddExpense("Food & Snacks", -1D))
        Rejects("Reject missing category", Sub() ledger.AddExpense("", 1D))
        Rejects("Reject fractional cents in model", Sub() ledger.AddExpense("Food & Snacks", 1.001D))
        Rejects("Reject negative savings", Sub() ledger.Calculate(-1D, 0D))
        Check("Failed expense leaves ledger unchanged", ledger.ExpenseCount = 0)
        ledger.Reset()
        For i As Integer = 1 To 100
            ledger.AddIncome(1000000D, 0D)
        Next
        Rejects("Reject total income cap overflow", Sub() ledger.AddIncome(0.01D, 0D))
        Check("Income cap leaves total unchanged", ledger.TotalIncome = 100000000D)
        For i As Integer = 1 To 100
            ledger.AddExpense("Food & Snacks", 1000000D)
        Next
        Rejects("Reject total expense cap overflow", Sub() ledger.AddExpense("Food & Snacks", 0.01D))
        Check("Expense cap leaves total unchanged", ledger.TotalExpenses = 100000000D)
        ledger.Reset()
        Check("Reset clears all model state", ledger.TotalIncome = 0D AndAlso ledger.TotalExpenses = 0D AndAlso ledger.ExpenseCount = 0)
        ' Regression checks for fields and actions visible in the Deliverable 2 mock-up.
        ledger.AddIncome(100D, 20D, 10D, 5D)
        Check("Four income sources total 135", ledger.TotalIncome = 135D)
        Check("Allowance source retained", ledger.TotalAllowance = 100D)
        Check("Extra money source retained", ledger.TotalExtraMoney = 20D)
        Check("Gift money source retained", ledger.TotalGiftMoney = 10D)
        Check("Other income source retained", ledger.TotalOtherIncome = 5D)
        result = ledger.Calculate(25D, 100D)
        Check("Amount Saved explicit output", result.AmountSaved = 25D)
        Check("Savings progress 25 percent", result.SavingsProgress = 25D)
        Check("Savings progress caps at 100", ledger.Calculate(120D, 100D).SavingsProgress = 100D)
        Check("Zero goal progress avoids division", ledger.Calculate(0D, 0D).SavingsProgress = 100D)
        Check("Savings shortage contains amount", result.SavingsStatus = "Amount still needed: BZ$ 75.00")
        ledger.AddExpense("Food & Snacks", 30D)
        ledger.AddExpense("Transportation", 5D)
        ledger.RemoveExpense(0)
        Check("Remove first row reduces total", ledger.TotalExpenses = 5D AndAlso ledger.ExpenseCount = 1)
        Check("Removal recalculates balance", ledger.Calculate(0D, 0D).RemainingBalance = 130D)
        ledger.RemoveExpense(0)
        Check("Remove last row clears expenses", ledger.TotalExpenses = 0D AndAlso ledger.ExpenseCount = 0)
        Rejects("Remove with no selection rejected", Sub() ledger.RemoveExpense(-1))
        Rejects("Remove invalid row rejected", Sub() ledger.RemoveExpense(20))
        Rejects("Negative extra money rejected", Sub() ledger.AddIncome(0D, -1D, 0D, 0D))
        Rejects("Negative gift money rejected", Sub() ledger.AddIncome(0D, 0D, -1D, 0D))
        Check("Invalid four-source transaction leaves totals intact", ledger.TotalIncome = 135D)
        ledger.AddExpense("Food & Snacks", 108D)
        Check("Four-source 80 percent warning", ledger.Calculate(25D, 100D).BudgetStatus.StartsWith("Warning:"))
        ledger.AddExpense("Entertainment", 28D)
        Check("Four-source overspend balance", ledger.Calculate(25D, 100D).RemainingBalance = -1D)
        ledger.RemoveExpense(1)
        Check("Remove overspend restores warning", ledger.Calculate(25D, 100D).BudgetStatus.StartsWith("Warning:"))
        ledger.Reset()
        Check("Reset clears all four income sources", ledger.TotalAllowance = 0D AndAlso ledger.TotalExtraMoney = 0D AndAlso ledger.TotalGiftMoney = 0D AndAlso ledger.TotalOtherIncome = 0D)
        Console.WriteLine("RESULT: " & passed.ToString() & " passed; " & failed.ToString() & " failed.")
        Environment.ExitCode = If(failed = 0, 0, 1)
    End Sub

    Private Sub Check(name As String, condition As Boolean)
        If condition Then
            passed += 1
            Console.WriteLine("PASS | " & name)
        Else
            failed += 1
            Console.WriteLine("FAIL | " & name)
        End If
    End Sub

    Private Sub Rejects(name As String, action As Action)
        Try
            action()
            Check(name, False)
        Catch ex As ArgumentException
            Check(name, True)
        End Try
    End Sub
End Module
