# Deliverable 2 to Deliverable 3 - requirement comparison
Reference: supplied BudgetBuddy_Deliverable_2.docx.pdf, including the visual mock-up on PDF page 2.

The mock-up contains more controls than the later control-name table. This revision implements both: the named controls/events and the additional fields/actions shown in the picture.

| Plan requirement | Revised implementation | Where to inspect |
| --- | --- | --- |
| Income, Expenses and Savings side by side | Three colored groups at top; summary beneath | MainForm.Designer.vb, grpIncome / grpExpense / grpSavings / grpSummary |
| Allowance (weekly/monthly) | txtAllowance, recorded by Add Income | MainForm.vb, btnAddIncome_Click |
| Extra Money Received in mock-up | Separate txtExtraMoney; accumulated separately | BudgetLogic.vb, TotalExtraMoney |
| Gift Money in mock-up | Separate txtGiftMoney; accumulated separately | BudgetLogic.vb, TotalGiftMoney |
| Other Income / txtOtherIncome | Separate input; all four sources contribute to total | BudgetLogic.vb, AddIncome overload with four arguments |
| Add Income and prevent accidental repeat | Validate whole entry, add once, clear all four fields after success | MainForm.vb, btnAddIncome_Click |
| Six expense categories | Food & Snacks, Transportation, School Supplies, Entertainment, Games/Applications, Other Expenses | cboExpenseCategory.DropDownList |
| Amount / Add Expense | Required positive amount; row with category and amount | btnAddExpense_Click |
| Expense table with Remove shown in mock-up | Read-only DataGridView with visible headers; select row; Remove updates ledger, display, totals and status | btnRemoveExpense_Click / BudgetLedger.RemoveExpense |
| Current Savings and Savings Goal | Two required, validated non-negative inputs | txtCurrentSavings / txtSavingsGoal |
| Total Income / Total Available | Sum of cumulative allowance + extra + gifts + other | lblTotalAvailable |
| Total Expenses | Sum of remaining expense rows | lblTotalExpenses |
| Remaining Balance | Income minus expenses; negative allowed and highlighted | lblRemainingBalance |
| Amount Saved in mock-up | Explicit summary output equal to current savings input | lblAmountSaved |
| Amount Needed to Reach Goal | max(0, goal - current savings) | lblSavingsNeeded |
| Savings progress in main-screen description | Percentage + progress bar; 100% at/above goal; zero goal achieved | lblSavingsProgress / prgSavings |
| Spending Percentage | Expenses / income x 100; N/A at zero income | lblSpendingPercentage |
| Budget Status | Over budget first; warning at >=80%; otherwise within budget; zero-income instruction | lblBudgetStatus / BudgetLedger.Calculate |
| Savings Status | Goal achieved, or explicit remaining amount | lblSavingsStatus |
| Calculate / View Budget | Single btnViewBudget labeled Calculate / View Budget | btnViewBudget_Click |
| Reset | Confirmation; clears all entries, history and labels | btnReset_Click |
| Exit | Closes the application | btnExit_Click |
| Missing/non-numeric/negative input | Validated before posting/calculation; specific feedback | MoneyInput.TryRead / ReadMoney |
| Money precision | Decimal and two-decimal display; fractional cents rejected | BudgetLogic.vb / Money formatter |
| Initial zero / instruction outputs | Zero figures and initial status until data entered | Designer and Reset handler |
| Commented major logic | Comments for posting, removal, progress, division guard and reset | MainForm.vb / BudgetLogic.vb |

Total Available includes extra and gift money as income, rather than ignoring sources shown in the mock-up. Current savings remain a separate stock of money: they are displayed in Amount Saved and used for goal progress, but are not automatically added to or deducted from the spending budget.

## Verification limits
Both .NET Framework 4.8 projects compile. The exact revised BudgetLogic.vb and console-check source were linked into a temporary .NET 10 console project and executed on Linux: 70 passed, 0 failed. Tests cover the added sources, removal, progress, warnings, validation, caps and reset. No claim is made that designer rendering or user clicks have been verified on Windows. Run the manual cases in the PDF on your Windows PC and capture actual screenshots.

Visual revision: plain Panels replace nested tables; title AutoSize prevents clipping; App.config opts into PerMonitorV2 and the Windows compatibility manifest is included. Native drawing supplies the wallet and gradient. Windows/DPI appearance still requires manual verification.
