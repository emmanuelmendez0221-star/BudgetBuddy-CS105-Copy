# BudgetBuddy - Windows Forms App (.NET Framework), Visual Basic
CS 105 | Deliverable 3 | Emmanuel Mendez and Andre Ramirez

## Open and run in Visual Studio 2026
1. Extract the ZIP with Windows **Extract All**.
2. In Visual Studio Installer > Modify, install **.NET desktop development**. In Individual components, ensure the **.NET Framework 4.8 targeting pack** and **.NET Framework 4.8 SDK** are installed.
3. Open **BudgetBuddy.sln**. This contains a classic Visual Basic Windows Forms project targeting **.NET Framework 4.8**.
4. If necessary, right-click BudgetBuddy > Set as Startup Project.
5. Build > Build Solution (Ctrl+Shift+B), then press F5 to run.
6. Right-click MainForm.vb > View Designer (Shift+F7) to edit the form. Use F4 for control properties. Keep the existing control names.

If creating a project manually, choose **Windows Forms App (.NET Framework)**, language **Visual Basic**, framework **.NET Framework 4.8**. Opening the supplied solution is easier because all controls and events are already connected.

## First example (all four income sources)
- Enter allowance 100, extra money received 20, gift money 10, and other income 5. Click Add Income.
- Select Food & Snacks, enter 30, and click Add Expense.
- Enter current savings 25 and savings goal 100. Click Calculate / View Budget.
- Expect BZ$ 135.00 total income, BZ$ 30.00 expenses, BZ$ 105.00 balance, Amount Saved BZ$ 25.00, 22.22% spent, BZ$ 75.00 needed, and 25% savings progress.
- Add another expense of 78: expenses total 108 and the 80% warning appears.
- Add another expense of 28: total 136 and balance -1, with over-budget warning.
- Select the 28 expense row and click Remove: total returns to 108 and the warning changes back to approaching the limit.

Use plain money values such as 125.50, no currency signs or commas, at most two decimal places. Each entry is limited to 1,000,000 and recorded totals to 100,000,000. Blank income fields count as zero, but the combined income must be positive. Both savings fields are required for View Budget; enter 0 when appropriate.

Successful income/expense entries clear their fields to prevent duplicate clicks. View Budget prompts you to record or clear pending entries. Savings are separate from spending money and do not change the spending balance. A savings goal of zero counts as achieved (100% progress).

The interface now follows the PDF page 2 mock-up: Income, Expenses, Savings across the top; Budget Summary below; Calculate, Reset and Exit at the bottom. The form now uses ordinary Panels and clearly aligned controls to keep the Designer simple. The mock-up composition uses a fixed-size window with scrollbars available when needed. The title autosizes instead of clipping. REQUIREMENTS_CHECKLIST.md maps every planned field, output and action to the source.

## Files
- BudgetBuddy.sln: open this solution.
- BudgetBuddy/BudgetBuddy.vbproj: classic .NET Framework 4.8 VB project.
- Program.vb: startup Sub Main using .NET Framework Windows Forms APIs.
- MainForm.Designer.vb: designer-editable interface controls.
- MainForm.vb: events, validation feedback, display updates, reset and exit.
- BudgetLogic.vb: calculations, amount checks, category records and budget decisions.
- App.config: .NET Framework 4.8 runtime selection and PerMonitorV2 DPI awareness.
- app.manifest: Windows compatibility and standard common-controls styling.
- Header paint handler: gradient and wallet drawn directly as shapes, without a stretched bitmap.
- Evidence: actual build logs, the original compiler-error correction and logic results.
- Deliverable_3_Report.md: editable report text for adding your Windows results and screenshots.

## Optional console logic checks on Windows
The separate BudgetBuddy.Tests folder also contains a .NET Framework 4.8 project. Open its .vbproj in another Visual Studio window, build, and run with Ctrl+F5. Expected result: 70 passed; 0 failed. It links the same BudgetLogic.vb file used by the form. This console project is deliberately outside the main solution so F5 on the main solution opens the app.

The included revised logic execution log was produced under .NET 10 on Linux, linking the exact revised BudgetLogic.vb and test source. Both .NET Framework 4.8 projects were compiled separately. Windows execution is still pending; record your own actual results.

## Finish your submission
Run the manual cases in the PDF on Windows. Capture the form showing a normal budget, the 80% warning, an over-budget balance, invalid input feedback, and the Visual Studio successful build/Error List. Add your actual results and screenshots to the report, then export the final PDF. The supplied report identifies Windows checks as pending.

The included compiler incident was a real nullable-type error in the test harness, corrected with HasValue and GetValueOrDefault. If your instructor specifically wants syntax-error evidence in Visual Studio, use a separate temporary copy, remove one End If, build and capture the diagnostic, restore End If, then rebuild. Label this as a controlled exercise and keep the working submission intact.

Zip the updated solution folder and submit it together with the PDF. Keep .sln, .vbproj, .vb and App.config files. You can omit bin, obj and .vs folders.

## Remaining features
No saving/loading, expense editing, date filtering, period history, charts or export. Expense removal is implemented. Closing loses the session. Reset asks for confirmation; Exit closes directly. Designer layout, scaling and all interface interactions still need Windows verification.


## Visual and DPI revision
- Added the .NET Framework PerMonitorV2 configuration, Windows compatibility manifest and 96-DPI design baseline.
- Replaced nested TableLayoutPanels with plain Panels; the dotted Designer outlines are normal selection guides and do not appear in the running app.
- Added a gradient header, a wallet drawn as shapes, colored section headers, field-like summary outputs, and Calculate / Reset / Exit aligned along the bottom.
- Replaced the expense ListView with a read-only DataGridView using visible headers, full-row selection, and fixed row order so Remove deletes the selected record.
- The title now autosizes. Keep App.config and app.manifest in the project; Visual Studio embeds/copies their settings during the build.
- Close the earlier solution, extract the new ZIP into a new folder, open its BudgetBuddy.sln, then Build > Rebuild Solution and F5.
- If the app's EXE has a manually enabled Windows Compatibility > Change high DPI settings override, clear that override so the app can use its built-in DPI settings.
- New Windows screenshots at 100%, 125% and 150% scaling are still needed. The Linux build verifies compilation and embedded manifest use, not the final Windows rendering.

Microsoft reference: https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms?view=netframeworkdesktop-4.8


## Designer error correction
If Visual Studio displayed "Method System.Windows.Forms.DataGridView.Columns not found", close the Designer without saving. The revised ZIP replaces indexed column assignments with explicit column fields and AddRange initialization. Extract this ZIP into a new folder even if you saved after Ignore and Continue, then open the new solution, Rebuild Solution, and right-click MainForm.vb > View Designer. Do not keep saving a Designer that reports unresolved errors. A successful build is verified; opening this corrected form in the Windows Designer remains to be checked.


## Testing report evidence
The updated PDF focuses on testing, a controlled missing-End-If syntax exercise, the observed Designer error/correction, and remaining work. Actual compiler logs and before/after snippets for the syntax exercise are included under Evidence/SyntaxExercise. The exercise ran in a temporary project copy; the working application source remains corrected.
